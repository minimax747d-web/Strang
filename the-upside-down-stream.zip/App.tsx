import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { VideoDetail } from './pages/VideoDetail';
import { Login } from './pages/Login';
import { AdminDashboard } from './pages/AdminDashboard';
import { NotFound } from './pages/NotFound';
import { AuthState } from './types';
import { LanguageProvider } from './contexts/LanguageContext';

const App: React.FC = () => {
  const [auth, setAuth] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
  });

  // Check for existing session on load
  useEffect(() => {
    const storedAuth = localStorage.getItem('aura_auth');
    if (storedAuth) {
      setAuth(JSON.parse(storedAuth));
    }
  }, []);

  const handleLogin = () => {
    const newAuth = {
      isAuthenticated: true,
      user: { username: 'Rafis', role: 'admin' as const },
    };
    setAuth(newAuth);
    localStorage.setItem('aura_auth', JSON.stringify(newAuth));
  };

  const handleLogout = () => {
    setAuth({ isAuthenticated: false, user: null });
    localStorage.removeItem('aura_auth');
  };

  return (
    <LanguageProvider>
      <HashRouter>
        <div className="min-h-screen text-zinc-200 font-sans selection:bg-stranger-neon selection:text-white">
          <Navbar auth={auth} onLogout={handleLogout} />
          
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/video/:id" element={<VideoDetail />} />
            <Route 
              path="/login" 
              element={
                auth.isAuthenticated ? <Navigate to="/admin" replace /> : <Login onLogin={handleLogin} />
              } 
            />
            <Route 
              path="/admin" 
              element={
                auth.isAuthenticated ? <AdminDashboard /> : <Navigate to="/login" replace />
              } 
            />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
      </HashRouter>
    </LanguageProvider>
  );
};

export default App;