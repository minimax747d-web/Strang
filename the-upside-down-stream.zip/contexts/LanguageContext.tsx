import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'ru';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    "discover": "Discover",
    "studio": "Studio",
    "logout": "Logout",
    "admin": "Admin",
    "featured_premiere": "Now Streaming in Hawkins",
    "start_tape": "Start Tape",
    "top_picks": "Top Picks",
    "views": "views",
    "viewers": "Viewers",
    "share": "Share Signal",
    "broadcasting": "Broadcasting",
    "restricted_title": "Restricted Content",
    "restricted_desc": "This footage contains anomalies from the Upside Down. Viewer discretion is mandatory.",
    "return_home": "Return to Base",
    "watch_now": "Watch Now",
    "login_title": "Hawkins Lab",
    "login_subtitle": "Restricted Access Only",
    "agent_id": "Agent ID",
    "passcode": "Passcode",
    "verify": "Verify Credentials",
    "return_surface": "Return to Surface",
    "control_room": "Control Room",
    "manage_signals": "Manage Broadcast Signals",
    "active_tapes": "Active Tapes",
    "total_impressions": "Total Impressions",
    "network_status": "Network Status",
    "upload_footage": "Upload Footage",
    "tape_not_found": "Tape Not Found",
    "back_browse": "Back to Browse",
    "case_file": "Case File Description",
    "about_video": "About this footage",
    "confirm_delete": "CONFIRM DELETION: This record will be permanently erased.",
    "new_tape": "New Tape",
    "archives_empty": "ARCHIVES EMPTY. UPLOAD FOOTAGE.",
    "access_denied": "ACCESS DENIED. INVALID CREDENTIALS.",
    "page_404": "You're in the Upside Down",
    "signal_lost": "Signal Lost. Return to safety immediately.",
    "escape": "Escape"
  },
  ru: {
    "discover": "Обзор",
    "studio": "Студия",
    "logout": "Выйти",
    "admin": "Вход",
    "featured_premiere": "Прямой эфир из Хоукинса",
    "start_tape": "Запустить кассету",
    "top_picks": "Лучшее",
    "views": "просмотров",
    "viewers": "Зрители",
    "share": "Поделиться",
    "broadcasting": "В эфире",
    "restricted_title": "Секретные материалы",
    "restricted_desc": "Запись содержит аномалии с Изнанки. Просмотр только для персонала.",
    "return_home": "Вернуться на базу",
    "watch_now": "Смотреть",
    "login_title": "Лаборатория Хоукинса",
    "login_subtitle": "Доступ ограничен",
    "agent_id": "ID Агента",
    "passcode": "Код доступа",
    "verify": "Подтвердить",
    "return_surface": "Вернуться на поверхность",
    "control_room": "Центр управления",
    "manage_signals": "Управление сигналами",
    "active_tapes": "Активные записи",
    "total_impressions": "Всего показов",
    "network_status": "Статус сети",
    "upload_footage": "Загрузить запись",
    "tape_not_found": "Кассета не найдена",
    "back_browse": "Назад к списку",
    "case_file": "Материалы дела",
    "about_video": "О записи",
    "confirm_delete": "ПОДТВЕРДИТЕ УДАЛЕНИЕ: Запись будет стерта навсегда.",
    "new_tape": "Новая кассета",
    "archives_empty": "АРХИВ ПУСТ. ЗАГРУЗИТЕ ЗАПИСЬ.",
    "access_denied": "ДОСТУП ЗАПРЕЩЕН. НЕВЕРНЫЕ ДАННЫЕ.",
    "page_404": "Вы на Изнанке",
    "signal_lost": "Сигнал потерян. Вернитесь в безопасную зону.",
    "escape": "Побег"
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};