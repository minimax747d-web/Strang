import React, { useEffect, useState, useRef } from 'react';
import { getVideos, addVideo, deleteVideo } from '../services/storage';
import { Video } from '../types';
import { Trash2, Plus, Film, Image as ImageIcon, X, UploadCloud, Radio, AlertTriangle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export const AdminDashboard: React.FC = () => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [videoToDelete, setVideoToDelete] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const { t } = useLanguage();
  
  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [duration, setDuration] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const thumbInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    refreshVideos();
  }, []);

  const refreshVideos = () => {
    setVideos(getVideos());
  };

  const initiateDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setVideoToDelete(id);
  };

  const performDelete = () => {
    if (!videoToDelete) return;

    try {
      // 1. Update Storage
      deleteVideo(videoToDelete);
      
      // 2. Optimistic UI Update
      setVideos(prev => prev.filter(v => v.id !== videoToDelete));
      setVideoToDelete(null);
    } catch (err) {
      console.error("Delete failed", err);
      alert("Failed to delete video. Please try again.");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'video' | 'image') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (type === 'image') {
        // Limit image size to prevent localStorage quota errors (approx 500KB limit for safety)
        if (file.size > 500 * 1024) {
            setErrorMsg("Image is too large. Please use an image under 500KB.");
            return;
        }
        setErrorMsg('');
        
        // Convert image to Base64 for persistence in localStorage
        const reader = new FileReader();
        reader.onloadend = () => {
            setThumbnailUrl(reader.result as string);
        };
        reader.readAsDataURL(file);
    } else {
        // Video files use ObjectURL for session preview
        setErrorMsg('');
        const url = URL.createObjectURL(file);
        setVideoUrl(url);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    
    const newVideo: Video = {
      id: Date.now().toString(),
      title,
      description,
      thumbnailUrl: thumbnailUrl || 'https://picsum.photos/800/450',
      videoUrl: videoUrl,
      views: 0,
      uploadDate: new Date().toISOString(),
      duration: duration || '00:00'
    };

    try {
        addVideo(newVideo);
        // Update local state immediately to show the new video
        setVideos(prev => [newVideo, ...prev]);
        setIsModalOpen(false);
        resetForm();
    } catch (err: any) {
        setErrorMsg(err.message || "Failed to save video.");
    }
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setThumbnailUrl('');
    setVideoUrl('');
    setDuration('');
    setErrorMsg('');
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10 pb-6 border-b border-white/10">
          <div>
            <h1 className="text-3xl sm:text-4xl font-stranger font-bold text-white uppercase tracking-wider drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]">{t('control_room')}</h1>
            <p className="text-zinc-400 mt-2 font-mono text-xs sm:text-sm uppercase tracking-widest">{t('manage_signals')}</p>
          </div>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="w-full sm:w-auto relative z-30 flex items-center justify-center gap-2 bg-stranger-neon hover:bg-red-600 text-white px-8 py-3 rounded-lg font-bold uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(255,51,51,0.4)] hover:shadow-[0_0_35px_rgba(255,51,51,0.6)] cursor-pointer touch-manipulation"
          >
            <Plus className="w-5 h-5" />
            {t('new_tape')}
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <div className="glass-panel border-white/5 p-6 sm:p-8 rounded-2xl shadow-[0_0_30px_rgba(0,0,0,0.5)] relative overflow-hidden group hover:border-stranger-neon/40 transition-all">
                <span className="text-stranger-neon text-xs font-bold uppercase tracking-widest">{t('active_tapes')}</span>
                <p className="text-4xl sm:text-5xl font-stranger text-white mt-4">{videos.length}</p>
                <div className="absolute top-0 right-0 w-32 h-32 bg-stranger-neon/5 rounded-full blur-2xl group-hover:bg-stranger-neon/15 transition-colors"></div>
            </div>
            <div className="glass-panel border-white/5 p-6 sm:p-8 rounded-2xl shadow-[0_0_30px_rgba(0,0,0,0.5)] relative overflow-hidden group hover:border-stranger-neon/40 transition-all">
                <span className="text-stranger-neon text-xs font-bold uppercase tracking-widest">{t('total_impressions')}</span>
                <p className="text-4xl sm:text-5xl font-stranger text-white mt-4">{new Intl.NumberFormat('en-US').format(videos.reduce((acc, curr) => acc + curr.views, 0))}</p>
                 <div className="absolute top-0 right-0 w-32 h-32 bg-stranger-neon/5 rounded-full blur-2xl group-hover:bg-stranger-neon/15 transition-colors"></div>
            </div>
            <div className="glass-panel border-white/5 p-6 sm:p-8 rounded-2xl shadow-[0_0_30px_rgba(0,0,0,0.5)] relative overflow-hidden group hover:border-stranger-neon/40 transition-all">
                <span className="text-stranger-neon text-xs font-bold uppercase tracking-widest">{t('network_status')}</span>
                <div className="flex items-center gap-3 mt-5">
                    <Radio className="w-6 h-6 text-red-500 animate-[pulse_1s_infinite]" />
                    <p className="text-xl sm:text-2xl font-mono text-white tracking-widest uppercase">{t('broadcasting')}</p>
                </div>
                 <div className="absolute top-0 right-0 w-32 h-32 bg-stranger-neon/5 rounded-full blur-2xl group-hover:bg-stranger-neon/15 transition-colors"></div>
            </div>
        </div>

        {/* Video List - Horizontal Scroll wrapper for mobile */}
        <div className="glass-panel border-white/5 rounded-2xl shadow-2xl overflow-hidden relative z-10">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[600px] md:min-w-0">
                <thead>
                <tr className="bg-white/5 text-zinc-400 text-xs font-mono uppercase tracking-widest border-b border-white/5">
                    <th className="p-4 sm:p-6 font-bold">Footage</th>
                    <th className="p-4 sm:p-6 font-bold hidden sm:table-cell">Date</th>
                    <th className="p-4 sm:p-6 font-bold hidden md:table-cell">Data</th>
                    <th className="p-4 sm:p-6 font-bold text-right">Actions</th>
                </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                {videos.map((video) => (
                    <tr key={video.id} className="hover:bg-stranger-neon/5 transition-colors group">
                    <td className="p-4 sm:p-6">
                        <div className="flex items-center gap-3 sm:gap-5">
                        <div className="w-20 sm:w-32 h-14 sm:h-20 bg-black border border-white/10 rounded-lg overflow-hidden flex-shrink-0 relative group-hover:border-stranger-neon/50 transition-colors shadow-lg">
                            <img src={video.thumbnailUrl} alt="" className="w-full h-full object-cover transition-all" />
                        </div>
                        <div>
                            <h3 className="text-sm sm:text-lg text-white font-bold font-sans tracking-wide line-clamp-1 group-hover:text-stranger-neon transition-colors">{video.title}</h3>
                            <p className="text-zinc-500 text-xs font-mono line-clamp-1 mt-1">{video.duration}</p>
                        </div>
                        </div>
                    </td>
                    <td className="p-4 sm:p-6 text-zinc-400 text-xs font-mono hidden sm:table-cell">
                        {new Date(video.uploadDate).toLocaleDateString()}
                    </td>
                    <td className="p-4 sm:p-6 text-zinc-400 text-xs font-mono hidden md:table-cell">
                        {video.views} {t('viewers').toUpperCase()}
                    </td>
                    <td className="p-4 sm:p-6 text-right">
                        <button 
                        type="button"
                        onClick={(e) => initiateDelete(video.id, e)}
                        className="relative z-20 bg-red-500/10 text-red-500 hover:bg-red-600 hover:text-white p-3 rounded-full transition-all duration-200 cursor-pointer shadow-sm hover:shadow-[0_0_15px_rgba(239,68,68,0.5)] active:scale-95 group-hover:bg-red-500/20 touch-manipulation"
                        title="Erase Tape"
                        >
                        <Trash2 className="w-5 h-5 pointer-events-none" />
                        </button>
                    </td>
                    </tr>
                ))}
                {videos.length === 0 && (
                    <tr>
                        <td colSpan={4} className="p-16 text-center text-zinc-500 font-mono tracking-widest">
                            {t('archives_empty')}
                        </td>
                    </tr>
                )}
                </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {videoToDelete && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/90 backdrop-blur-sm" onClick={() => setVideoToDelete(null)} />
            <div className="relative bg-[#0a0a0a] border border-red-600/30 w-full max-w-md p-6 sm:p-8 rounded-2xl shadow-[0_0_50px_rgba(220,38,38,0.25)] animate-in fade-in zoom-in duration-200 mx-4">
                <div className="flex items-center gap-4 mb-6 text-red-500">
                    <div className="p-3 bg-red-500/10 rounded-full border border-red-500/20">
                        <Trash2 className="w-8 h-8" />
                    </div>
                    <h3 className="text-xl font-stranger font-bold uppercase tracking-wider text-white">Confirm Deletion</h3>
                </div>
                
                <p className="text-zinc-400 font-mono text-sm leading-relaxed mb-8">
                    Are you sure you want to erase this tape from the archives? This action cannot be undone.
                </p>

                <div className="flex flex-col sm:flex-row justify-end gap-3">
                    <button 
                        onClick={() => setVideoToDelete(null)}
                        className="w-full sm:w-auto px-6 py-3 rounded-lg text-zinc-500 hover:text-white hover:bg-white/5 transition-colors font-mono uppercase text-xs tracking-widest cursor-pointer touch-manipulation"
                    >
                        Cancel
                    </button>
                    <button 
                        onClick={performDelete}
                        className="w-full sm:w-auto px-6 py-3 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(220,38,38,0.4)] transition-all cursor-pointer hover:shadow-[0_0_30px_rgba(220,38,38,0.6)] touch-manipulation"
                    >
                        Erase Tape
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* Upload Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" onClick={() => setIsModalOpen(false)} />
          
          <div className="relative bg-[#0a0a0a] border border-stranger-neon/40 w-full max-w-2xl shadow-[0_0_80px_rgba(255,51,51,0.25)] rounded-2xl p-6 md:p-10 animate-in fade-in zoom-in duration-300 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl sm:text-3xl font-stranger font-bold text-white uppercase tracking-wider text-shadow">{t('upload_footage')}</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-zinc-500 hover:text-white transition-colors cursor-pointer p-2">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            {errorMsg && (
                <div className="mb-6 p-4 bg-red-900/30 border border-red-500/50 rounded-lg flex items-start gap-3 text-red-200 text-sm">
                    <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />
                    <p>{errorMsg}</p>
                </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6 pb-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                <div className="md:col-span-2 space-y-4">
                    <label className="block text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2">Video Source</label>
                    <div className="border-2 border-dashed border-zinc-800 hover:border-stranger-neon bg-black/30 rounded-xl p-6 sm:p-10 text-center transition-all cursor-pointer group" onClick={() => fileInputRef.current?.click()}>
                        <input 
                            type="file" 
                            ref={fileInputRef} 
                            className="hidden" 
                            accept="video/*"
                            onChange={(e) => handleFileChange(e, 'video')}
                        />
                         <div className="flex flex-col items-center gap-3 text-zinc-500 group-hover:text-stranger-neon transition-colors">
                            {videoUrl && videoUrl.startsWith('blob:') ? (
                                <>
                                    <Film className="w-10 h-10 sm:w-12 sm:h-12 text-stranger-neon drop-shadow-[0_0_15px_rgba(255,51,51,0.8)]" />
                                    <span className="text-xs font-mono uppercase tracking-widest font-bold">Local Tape Loaded</span>
                                </>
                            ) : (
                                <>
                                    <UploadCloud className="w-10 h-10 sm:w-12 sm:h-12" />
                                    <span className="text-xs font-mono uppercase tracking-widest font-bold">Select Local File</span>
                                </>
                            )}
                         </div>
                    </div>
                     <input
                        type="text"
                        placeholder="OR ENTER DIRECT MP4 URL"
                        value={videoUrl}
                        onChange={(e) => setVideoUrl(e.target.value)}
                        className="w-full bg-black/50 border border-zinc-800 rounded-lg px-4 py-3 text-base md:text-xs font-mono text-zinc-300 focus:border-stranger-neon focus:outline-none placeholder-zinc-700 focus:ring-1 focus:ring-stranger-neon"
                      />
                </div>

                <div className="md:col-span-2">
                     <label className="block text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2">Thumbnail</label>
                     <div className="flex flex-col sm:flex-row gap-4">
                        <button type="button" onClick={() => thumbInputRef.current?.click()} className="px-5 py-3 bg-zinc-900 border border-zinc-700 rounded-lg text-xs font-mono text-zinc-300 hover:border-stranger-neon hover:text-white transition-colors uppercase tracking-wider shrink-0 cursor-pointer touch-manipulation">Upload Image</button>
                        <input 
                            type="file" 
                            ref={thumbInputRef} 
                            className="hidden" 
                            accept="image/*"
                            onChange={(e) => handleFileChange(e, 'image')}
                        />
                        <input
                            type="text"
                            placeholder="OR IMAGE URL"
                            value={thumbnailUrl}
                            onChange={(e) => setThumbnailUrl(e.target.value)}
                            className="flex-1 bg-black/50 border border-zinc-800 rounded-lg px-4 py-3 text-base md:text-xs font-mono text-zinc-300 focus:border-stranger-neon focus:outline-none placeholder-zinc-700"
                        />
                     </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2">Title</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full bg-black/50 border border-zinc-800 rounded-lg px-4 py-3 text-white font-sans tracking-wide focus:border-stranger-neon focus:shadow-[0_0_15px_rgba(255,51,51,0.2)] focus:outline-none transition-all placeholder-zinc-700 text-base md:text-sm"
                    placeholder="EPISODE TITLE"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2">Description</label>
                  <textarea
                    required
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full bg-black/50 border border-zinc-800 rounded-lg px-4 py-3 text-zinc-300 font-sans focus:border-stranger-neon focus:shadow-[0_0_15px_rgba(255,51,51,0.2)] focus:outline-none transition-all resize-none placeholder-zinc-700 text-base md:text-sm"
                    placeholder="Classified details..."
                  />
                </div>

                 <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2">Duration</label>
                  <input
                    type="text"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    className="w-full bg-black/50 border border-zinc-800 rounded-lg px-4 py-3 text-white font-mono focus:border-stranger-neon focus:outline-none transition-all placeholder-zinc-700 text-base md:text-sm"
                    placeholder="00:00"
                  />
                </div>
              </div>

              <div className="flex flex-col-reverse sm:flex-row justify-end gap-3 pt-6 border-t border-white/5 pb-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-6 py-4 sm:py-3 rounded-lg text-zinc-500 hover:text-white hover:bg-white/5 transition-colors font-mono uppercase text-xs tracking-widest cursor-pointer touch-manipulation text-center"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!videoUrl || !title}
                  className="px-8 py-4 sm:py-3 rounded-lg bg-stranger-neon text-white font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(255,51,51,0.4)] hover:bg-red-600 hover:shadow-[0_0_35px_rgba(255,51,51,0.6)] transition-all disabled:opacity-50 disabled:cursor-not-allowed transform hover:-translate-y-0.5 cursor-pointer touch-manipulation text-center"
                >
                  Broadcast
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};