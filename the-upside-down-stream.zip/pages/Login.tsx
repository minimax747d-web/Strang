import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, ArrowRight, Zap } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface LoginProps {
  onLogin: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { t } = useLanguage();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'Rafis' && password === '11Leto@2010') {
      onLogin();
      navigate('/admin');
    } else {
      setError(t('access_denied'));
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
      
      {/* Brighter Upside Down Atmosphere */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#1a0505] to-[#050505]"></div>
      <div className="absolute top-0 left-0 w-full h-full opacity-50 pointer-events-none">
          {/* Enhanced animated glows */}
          <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-red-600/20 rounded-full blur-[120px] animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-purple-600/10 rounded-full blur-[100px]"></div>
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="glass-panel border-stranger-neon/30 p-8 sm:p-12 shadow-[0_0_80px_rgba(255,51,51,0.2)] rounded-3xl relative backdrop-blur-2xl">
            {/* Neon borders */}
            <div className="absolute inset-0 rounded-3xl border border-white/5 pointer-events-none"></div>

          <div className="flex flex-col items-center mb-10">
            <div className="w-20 h-20 bg-gradient-to-br from-stranger-neon/20 to-black rounded-full flex items-center justify-center mb-6 border border-stranger-neon/50 shadow-[0_0_30px_rgba(255,51,51,0.4)]">
              <Zap className="w-10 h-10 text-stranger-neon drop-shadow-[0_0_10px_rgba(255,51,51,0.8)]" />
            </div>
            <h2 className="text-3xl font-stranger font-bold text-white uppercase tracking-wider drop-shadow-[0_0_10px_rgba(255,255,255,0.3)]">{t('login_title')}</h2>
            <p className="text-stranger-neon text-xs font-mono mt-3 uppercase tracking-[0.25em] font-bold shadow-red-500 drop-shadow-md">{t('login_subtitle')}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="group">
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 group-focus-within:text-stranger-neon transition-colors">{t('agent_id')}</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-4 text-white placeholder-zinc-700 focus:outline-none focus:border-stranger-neon focus:shadow-[0_0_20px_rgba(255,51,51,0.2)] transition-all font-mono text-base sm:text-sm"
                placeholder="ENTER ID"
                required
              />
            </div>
            
            <div className="group">
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 group-focus-within:text-stranger-neon transition-colors">{t('passcode')}</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-4 text-white placeholder-zinc-700 focus:outline-none focus:border-stranger-neon focus:shadow-[0_0_20px_rgba(255,51,51,0.2)] transition-all font-mono text-base sm:text-sm"
                placeholder="••••••••"
                required
              />
            </div>

            {error && (
              <div className="p-4 bg-red-950/40 border border-red-500/50 rounded-lg text-red-400 text-xs font-mono text-center tracking-widest animate-pulse shadow-[0_0_15px_rgba(220,38,38,0.2)]">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-stranger-neon to-red-600 text-white font-bold py-4 rounded-lg hover:to-red-500 transition-all flex items-center justify-center gap-3 group shadow-[0_0_30px_rgba(255,51,51,0.3)] hover:shadow-[0_0_50px_rgba(255,51,51,0.5)] uppercase tracking-widest text-sm hover:-translate-y-1 touch-manipulation cursor-pointer"
            >
              {t('verify')}
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>
          
          <div className="mt-8 text-center">
             <button 
                onClick={() => navigate('/')}
                className="text-xs font-mono text-zinc-500 hover:text-white transition-colors uppercase tracking-widest border-b border-transparent hover:border-white pb-0.5 touch-manipulation cursor-pointer"
            >
                {t('return_surface')}
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};