import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

export const NotFound: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center text-center px-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,#220000_0%,#000000_80%)] animate-pulse"></div>
      
      <div className="relative z-10">
        <h1 className="text-[12rem] font-stranger font-black text-transparent text-outline-red leading-none select-none drop-shadow-[0_0_40px_rgba(255,51,51,0.6)]">404</h1>
        <div className="mt-8 space-y-6">
            <h2 className="text-3xl font-stranger font-bold text-white uppercase tracking-widest">{t('page_404')}</h2>
            <p className="text-zinc-500 font-mono tracking-widest uppercase text-sm">{t('signal_lost')}</p>
            <div className="pt-8">
                <Link 
                    to="/"
                    className="inline-block px-10 py-4 bg-stranger-neon text-white font-bold uppercase tracking-[0.2em] hover:bg-red-600 hover:shadow-[0_0_40px_rgba(255,51,51,0.6)] transition-all rounded-sm"
                >
                    {t('escape')}
                </Link>
            </div>
        </div>
      </div>
    </div>
  );
};