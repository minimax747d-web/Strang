import React, { useEffect, useState } from 'react';
import { getVideos } from '../services/storage';
import { Video } from '../types';
import { VideoCard } from '../components/VideoCard';
import { Play, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

export const Home: React.FC = () => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [featured, setFeatured] = useState<Video | null>(null);
  const { t } = useLanguage();

  useEffect(() => {
    const allVideos = getVideos();
    setVideos(allVideos);
    if (allVideos.length > 0) {
      setFeatured(allVideos[0]);
    }
  }, []);

  return (
    <div className="min-h-screen pb-20">
      {/* Hero Section */}
      {featured && (
        <div className="relative w-full h-[90vh] flex items-end overflow-hidden border-b border-stranger-neon/30 shadow-[0_10px_50px_-10px_rgba(255,51,51,0.2)]">
          {/* Background Image */}
          <div className="absolute inset-0 z-0">
             <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/60 to-[#050505] z-10" />
             <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#050505_100%)] z-10 opacity-60" />
             <img 
               src={featured.thumbnailUrl} 
               alt="Hero" 
               className="w-full h-full object-cover object-top scale-105 animate-[pulse_10s_ease-in-out_infinite]"
             />
             {/* Modern animated grain */}
             <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-30 z-20 mix-blend-overlay"></div>
          </div>

          {/* Content */}
          <div className="relative z-30 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 md:pb-32">
            <div className="flex items-center gap-3 mb-6 animate-bounce duration-3000">
                <div className="p-2 bg-stranger-neon/20 rounded-full border border-stranger-neon/50 shadow-[0_0_15px_rgba(255,51,51,0.5)]">
                    <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="text-white font-mono text-xs sm:text-sm uppercase tracking-[0.25em] drop-shadow-[0_0_8px_rgba(255,51,51,0.8)] font-bold">
                {t('featured_premiere')}
                </span>
            </div>
            
            {/* Title with Modern Glow Effect - Responsive sizing */}
            <h1 className="text-4xl sm:text-6xl md:text-8xl font-stranger font-black text-transparent text-outline-red mb-6 md:mb-8 leading-[0.9] max-w-5xl drop-shadow-[0_0_30px_rgba(255,51,51,0.6)] tracking-wide">
              {featured.title}
            </h1>
            
            <div className="glass-panel p-4 sm:p-6 rounded-xl max-w-2xl mb-8 md:mb-12 border-l-4 border-l-stranger-neon shadow-[0_0_30px_rgba(0,0,0,0.5)]">
                 <p className="text-base sm:text-lg md:text-xl text-zinc-200 font-light leading-relaxed drop-shadow-md line-clamp-3 md:line-clamp-none">
                {featured.description}
                </p>
            </div>
            
            <div className="flex flex-wrap gap-6">
              <Link 
                to={`/video/${featured.id}`}
                className="group relative px-8 py-4 sm:px-10 sm:py-5 bg-stranger-neon text-white uppercase font-bold tracking-widest overflow-hidden transition-all rounded-sm hover:scale-105 hover:shadow-[0_0_40px_rgba(255,51,51,0.7)] text-sm sm:text-base"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-stranger-neon opacity-100"></div>
                <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
                <div className="flex items-center gap-3 relative z-10">
                    <Play className="w-5 h-5 fill-current" />
                    <span>{t('start_tape')}</span>
                </div>
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Video Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 relative z-30">
        <div className="flex items-center gap-6 mb-12">
          <h2 className="text-2xl sm:text-4xl font-stranger font-bold text-white tracking-widest uppercase drop-shadow-[0_0_10px_rgba(255,51,51,0.6)]">{t('top_picks')}</h2>
          <div className="h-0.5 flex-1 bg-gradient-to-r from-stranger-neon via-red-900/50 to-transparent shadow-[0_0_10px_rgba(255,51,51,0.8)]"></div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-10 sm:gap-y-16">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} />
          ))}
        </div>
        
        {videos.length === 0 && (
            <div className="text-center py-20 border border-dashed border-zinc-800 rounded-lg bg-black/50 backdrop-blur-sm">
                <p className="text-zinc-500 font-mono tracking-widest">{t('archives_empty')}</p>
            </div>
        )}
      </div>
    </div>
  );
};