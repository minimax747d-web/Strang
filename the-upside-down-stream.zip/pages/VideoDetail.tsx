import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Video } from '../types';
import { getVideoById, incrementViews } from '../services/storage';
import { ArrowLeft, Clock, Calendar, Share2, AlertTriangle, Radio } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export const VideoDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [video, setVideo] = useState<Video | null>(null);
  const { t } = useLanguage();

  useEffect(() => {
    if (id) {
      const found = getVideoById(id);
      if (found) {
        setVideo(found);
        setTimeout(() => incrementViews(id), 5000);
      }
    }
  }, [id]);

  if (!video) {
    return (
      <div className="min-h-screen flex items-center justify-center text-white">
        <div className="text-center space-y-4">
            <h2 className="text-4xl font-stranger text-stranger-neon drop-shadow-[0_0_20px_rgba(255,51,51,1)] animate-pulse">{t('tape_not_found')}</h2>
            <Link to="/" className="text-zinc-400 hover:text-white uppercase tracking-widest text-sm border-b border-transparent hover:border-white transition-all">{t('return_home')}</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Back Button */}
        <Link to="/" className="inline-flex items-center text-zinc-400 hover:text-stranger-neon mb-8 transition-colors uppercase tracking-widest text-xs font-bold group bg-white/5 px-4 py-2 rounded-full backdrop-blur-sm border border-white/5 hover:border-stranger-neon/30">
          <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
          {t('back_browse')}
        </Link>

        {/* Player Container - Modern Neon Style */}
        <div className="relative aspect-video w-full bg-zinc-950 rounded-2xl overflow-hidden shadow-[0_0_100px_rgba(255,51,51,0.2)] border border-stranger-neon/20 mb-10 group ring-1 ring-white/10">
          <video
            src={video.videoUrl}
            poster={video.thumbnailUrl}
            controls
            autoPlay
            className="w-full h-full object-contain"
          >
             Your browser does not support the video tag.
          </video>
          {/* Subtle Scanline overlay */}
          <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.1)_50%)] bg-[length:100%_4px] z-10 opacity-20"></div>
          
          <div className="absolute top-6 right-6 flex items-center gap-2 px-4 py-1.5 bg-red-600/20 border border-red-500/50 backdrop-blur-md rounded-full text-red-500 text-xs font-mono uppercase tracking-widest animate-[pulse_2s_infinite]">
            <Radio className="w-3 h-3" />
            <span className="font-bold">{t('broadcasting')}</span>
          </div>
        </div>

        {/* Info Header */}
        <div className="glass-panel rounded-2xl p-8 mb-8 flex flex-col md:flex-row md:items-start md:justify-between gap-6 shadow-[0_10px_30px_rgba(0,0,0,0.3)]">
          <div className="flex-1">
            <h1 className="text-4xl md:text-5xl font-stranger font-bold text-white mb-4 drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]">
              {video.title}
            </h1>
            <div className="flex items-center gap-6 text-zinc-400 text-sm font-mono tracking-wide">
                <div className="flex items-center gap-2 text-stranger-neon drop-shadow-[0_0_5px_rgba(255,51,51,0.5)]">
                    <span className="font-bold text-lg">{new Intl.NumberFormat('en-US').format(video.views)}</span>
                    <span className="uppercase text-xs tracking-wider">{t('views')}</span>
                </div>
                <div className="w-1 h-1 bg-zinc-600 rounded-full"></div>
                <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>{video.duration}</span>
                </div>
                <div className="w-1 h-1 bg-zinc-600 rounded-full"></div>
                <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(video.uploadDate).toLocaleDateString()}</span>
                </div>
            </div>
          </div>

          <button className="flex items-center justify-center gap-2 px-8 py-4 bg-white/5 hover:bg-stranger-neon/20 text-white border border-white/10 hover:border-stranger-neon rounded-lg transition-all font-mono uppercase text-sm tracking-widest shadow-lg hover:shadow-[0_0_30px_rgba(255,51,51,0.3)] h-fit">
            <Share2 className="w-4 h-4" />
            {t('share')}
          </button>
        </div>

        {/* Description */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 glass-panel p-8 rounded-2xl border-l-2 border-l-stranger-neon/50">
                <h3 className="text-xl font-bold text-stranger-neon font-stranger uppercase tracking-wider mb-6 drop-shadow-[0_0_8px_rgba(255,51,51,0.6)]">{t('case_file')}</h3>
                <p className="text-zinc-300 leading-loose text-lg font-light whitespace-pre-wrap font-sans">
                    {video.description}
                </p>
            </div>
            
            <div className="lg:col-span-1">
                 <div className="bg-gradient-to-br from-stranger-900/80 to-black border border-stranger-neon/30 p-8 rounded-2xl relative overflow-hidden shadow-[0_0_30px_rgba(220,38,38,0.15)]">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-stranger-neon/10 rounded-full blur-2xl -mr-8 -mt-8"></div>
                    <div className="flex items-start gap-4 relative z-10">
                        <AlertTriangle className="w-8 h-8 text-stranger-neon flex-shrink-0 animate-[bounce_3s_infinite]" />
                        <div>
                            <h4 className="text-white font-bold uppercase tracking-widest mb-2 text-sm drop-shadow-md">{t('restricted_title')}</h4>
                            <p className="text-sm text-zinc-400 leading-relaxed font-light">
                                {t('restricted_desc')}
                            </p>
                        </div>
                    </div>
                 </div>
            </div>
        </div>

      </div>
    </div>
  );
};