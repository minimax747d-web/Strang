import { Video } from '../types';

const STORAGE_KEY = 'aura_videos';

const INITIAL_VIDEOS: Video[] = [
  {
    id: '1',
    title: 'Stranger Things',
    description: 'The return of darkness in Hawkins and the reunion of friends',
    thumbnailUrl: 'https://images.ctfassets.net/4cd45et68cgf/5De6r883i75r7wQ7c1X1w/d95454655f4639911e3b5e4062e70c53/Stranger_Things_S4.jpg',
    videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    views: 8943201,
    uploadDate: '2022-05-27',
    duration: '1:18:30'
  },
  {
    id: '2',
    title: 'Midnight City Lights',
    description: 'Urban exploration at its finest. Low light cinematography capturing the soul of the sleeping city.',
    thumbnailUrl: 'https://picsum.photos/id/122/800/450',
    videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
    views: 8302,
    uploadDate: '2023-10-20',
    duration: '08:45'
  },
  {
    id: '3',
    title: 'Abstract Thoughts',
    description: 'A visual representation of the mind during deep meditation. Colors, shapes, and silence.',
    thumbnailUrl: 'https://picsum.photos/id/132/800/450',
    videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    views: 450,
    uploadDate: '2023-11-01',
    duration: '05:30'
  },
  {
    id: '4',
    title: 'Ocean Deep',
    description: 'Diving into the unknown depths. What lies beneath the surface?',
    thumbnailUrl: 'https://picsum.photos/id/149/800/450',
    videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    views: 32100,
    uploadDate: '2023-11-05',
    duration: '14:20'
  }
];

export const getVideos = (): Video[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_VIDEOS));
      return INITIAL_VIDEOS;
    }
    return JSON.parse(stored);
  } catch (error) {
    console.error("Failed to load videos from storage:", error);
    return INITIAL_VIDEOS;
  }
};

export const getVideoById = (id: string): Video | undefined => {
  const videos = getVideos();
  return videos.find((v) => v.id === id);
};

export const addVideo = (video: Video): void => {
  try {
    const videos = getVideos();
    const newVideos = [video, ...videos];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newVideos));
  } catch (error) {
    console.error("Failed to save video:", error);
    if (error instanceof DOMException && error.name === 'QuotaExceededError') {
       throw new Error("Storage is full. Try using a smaller image or clearing old videos.");
    }
    throw error;
  }
};

export const deleteVideo = (id: string): void => {
  try {
    const videos = getVideos();
    const newVideos = videos.filter((v) => v.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newVideos));
  } catch (error) {
    console.error("Failed to delete video:", error);
    throw error;
  }
};

export const incrementViews = (id: string): void => {
  try {
    const videos = getVideos();
    const index = videos.findIndex(v => v.id === id);
    if (index !== -1) {
      videos[index].views += 1;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(videos));
    }
  } catch (error) {
    console.error("Failed to increment views:", error);
  }
};