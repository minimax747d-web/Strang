import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Tv, Lock, LogOut, LayoutDashboard, Globe, Menu, X } from 'lucide-react';
import { AuthState } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface NavbarProps {
  auth: AuthState;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ auth, onLogout }) => {
  const location = useLocation();
  const { language, setLanguage, t } = useLanguage();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isTransparent = location.pathname === '/';

  const toggleMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const closeMenu = () => setIsMobileMenuOpen(false);

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b ${
        isTransparent && !isMobileMenuOpen
          ? 'glass-panel border-stranger-neon/20' 
          : 'bg-black/95 backdrop-blur-xl border-stranger-neon/30 shadow-[0_4px_30px_-5px_rgba(255,51,51,0.4)]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" onClick={closeMenu} className="flex items-center gap-2 group relative z-50">
             <div className="absolute -inset-2 bg-stranger-neon/20 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
             <div className="relative">
                 <Tv className="w-8 h-8 text-stranger-neon drop-shadow-[0_0_10px_rgba(255,51,51,0.8)]" />
             </div>
            <span className="text-3xl font-stranger font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-b from-red-500 to-red-100 drop-shadow-[0_0_15px_rgba(255,0,0,0.6)] group-hover:text-stranger-neon transition-all">
              STRANGER
            </span>
          </Link>

          {/* Mobile Menu Toggle */}
          <button 
            onClick={toggleMenu}
            className="md:hidden relative z-50 p-2 text-zinc-400 hover:text-stranger-neon transition-colors"
          >
            {isMobileMenuOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6">
            
            {/* Language Toggle */}
            <div className="flex items-center bg-black/40 rounded-full border border-stranger-neon/30 p-1 backdrop-blur-sm">
                <button 
                    onClick={() => setLanguage('en')}
                    className={`px-3 py-1 text-xs font-bold rounded-full transition-all ${language === 'en' ? 'bg-stranger-neon text-black shadow-[0_0_10px_rgba(255,51,51,0.5)]' : 'text-zinc-400 hover:text-white'}`}
                >
                    EN
                </button>
                <button 
                    onClick={() => setLanguage('ru')}
                    className={`px-3 py-1 text-xs font-bold rounded-full transition-all ${language === 'ru' ? 'bg-stranger-neon text-black shadow-[0_0_10px_rgba(255,51,51,0.5)]' : 'text-zinc-400 hover:text-white'}`}
                >
                    RU
                </button>
            </div>

            <div className="flex items-center gap-6">
                <Link 
                to="/" 
                className={`text-sm font-bold uppercase tracking-wider transition-all duration-300 hover:text-stranger-neon hover:drop-shadow-[0_0_8px_rgba(255,51,51,0.8)] ${
                    location.pathname === '/' ? 'text-white drop-shadow-[0_0_5px_rgba(255,255,255,0.5)]' : 'text-zinc-400'
                }`}
                >
                {t('discover')}
                </Link>
                
                {auth.isAuthenticated ? (
                <>
                    <Link 
                    to="/admin" 
                    className={`flex items-center gap-2 text-sm font-bold uppercase tracking-wider transition-all hover:text-stranger-neon hover:drop-shadow-[0_0_8px_rgba(255,51,51,0.8)] ${
                        location.pathname === '/admin' ? 'text-white' : 'text-zinc-400'
                    }`}
                    >
                    <LayoutDashboard className="w-4 h-4" />
                    {t('studio')}
                    </Link>
                    <button
                    onClick={onLogout}
                    className="flex items-center gap-2 px-4 py-2 rounded-full border border-stranger-neon/30 bg-white/5 hover:bg-stranger-neon/20 text-stranger-neon text-sm font-bold uppercase tracking-wider transition-all shadow-[0_0_10px_rgba(255,51,51,0.2)] hover:shadow-[0_0_20px_rgba(255,51,51,0.4)] cursor-pointer"
                    >
                    <LogOut className="w-4 h-4" />
                    {t('logout')}
                    </button>
                </>
                ) : (
                <Link
                    to="/login"
                    className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-gradient-to-r from-stranger-neon to-red-600 text-white hover:to-red-500 text-sm font-bold uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(255,51,51,0.4)] hover:shadow-[0_0_30px_rgba(255,51,51,0.6)] hover:scale-105 active:scale-95 border border-red-400/50"
                >
                    <Lock className="w-3 h-3" />
                    {t('admin')}
                </Link>
                )}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-black/95 backdrop-blur-xl border-b border-stranger-neon/30 p-6 flex flex-col gap-6 shadow-2xl animate-in slide-in-from-top-5 duration-200">
           {/* Mobile Language Toggle */}
           <div className="flex items-center justify-center bg-white/5 rounded-lg border border-white/10 p-2 gap-2">
                <button 
                    onClick={() => setLanguage('en')}
                    className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${language === 'en' ? 'bg-stranger-neon text-black' : 'text-zinc-400'}`}
                >
                    ENGLISH
                </button>
                <button 
                    onClick={() => setLanguage('ru')}
                    className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${language === 'ru' ? 'bg-stranger-neon text-black' : 'text-zinc-400'}`}
                >
                    РУССКИЙ
                </button>
            </div>

            <Link 
                to="/" 
                onClick={closeMenu}
                className={`text-xl font-bold uppercase tracking-wider text-center py-2 ${location.pathname === '/' ? 'text-white' : 'text-zinc-500'}`}
            >
                {t('discover')}
            </Link>

            {auth.isAuthenticated ? (
                <>
                    <Link 
                        to="/admin" 
                        onClick={closeMenu}
                        className={`text-xl font-bold uppercase tracking-wider text-center py-2 ${location.pathname === '/admin' ? 'text-white' : 'text-zinc-500'}`}
                    >
                        {t('studio')}
                    </Link>
                    <button
                        onClick={() => {
                            onLogout();
                            closeMenu();
                        }}
                        className="text-xl font-bold uppercase tracking-wider text-center py-2 text-stranger-neon"
                    >
                        {t('logout')}
                    </button>
                </>
            ) : (
                <Link
                    to="/login"
                    onClick={closeMenu}
                    className="flex items-center justify-center gap-2 px-6 py-4 rounded-lg bg-gradient-to-r from-stranger-neon to-red-600 text-white font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(255,51,51,0.4)]"
                >
                    <Lock className="w-4 h-4" />
                    {t('admin')}
                </Link>
            )}
        </div>
      )}
    </nav>
  );
};