import React from 'react';
import { Link } from 'react-router-dom';
import { Play } from 'lucide-react';
import { Video } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface VideoCardProps {
  video: Video;
}

export const VideoCard: React.FC<VideoCardProps> = ({ video }) => {
  const { t } = useLanguage();

  return (
    <Link to={`/video/${video.id}`} className="group block relative perspective-1000">
      <div className="relative aspect-video rounded-lg overflow-hidden bg-zinc-950 mb-5 border border-white/5 transition-all duration-500 group-hover:border-stranger-neon group-hover:shadow-[0_0_40px_-5px_rgba(255,51,51,0.5)] group-hover:-translate-y-2">
        {/* Image */}
        <img
          src={video.thumbnailUrl}
          alt={video.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80 group-hover:opacity-100"
          loading="lazy"
        />
        
        {/* Modern Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-80" />
        
        {/* Play Button Overlay - Modern Glass */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-16 h-16 flex items-center justify-center bg-stranger-neon/90 backdrop-blur-md shadow-[0_0_30px_rgba(255,51,51,0.8)] rounded-full transform scale-75 group-hover:scale-100 transition-transform">
            <Play className="w-6 h-6 text-white fill-white ml-1" />
          </div>
        </div>

        {/* Duration Badge */}
        <div className="absolute bottom-3 right-3 px-2 py-1 bg-black/60 backdrop-blur-md border border-white/10 rounded text-zinc-200 text-xs font-mono tracking-wider">
          {video.duration}
        </div>
      </div>

      <div className="space-y-2 px-1">
        <h3 className="text-xl font-bold text-zinc-100 leading-tight group-hover:text-stranger-neon group-hover:drop-shadow-[0_0_10px_rgba(255,51,51,0.5)] transition-all line-clamp-1 font-sans">
          {video.title}
        </h3>
        <div className="flex items-center text-xs text-zinc-400 font-mono uppercase tracking-widest">
          <span>{new Intl.NumberFormat('en-US').format(video.views)} {t('views')}</span>
          <span className="mx-2 text-stranger-neon">•</span>
          <span>{new Date(video.uploadDate).toLocaleDateString()}</span>
        </div>
      </div>
    </Link>
  );
};